leastascent <-
function(Budget, N) 
  #climbs to the least profitable neighborhood
{
  library(EMT)
  library(multcomp)
  X=findVectors(N, Budget) 
  Profit=NULL 
  #vector containing local maxima of each set of coefficients
  for (j in 1:1000)
  {
    c1=c(runif(N, -1,1))
    c2=c(runif(N, -1,1))
    c3=c(runif(choose(N-1,2), -1,1))
    for(i in 1:nrow(X))
    {
      XM=X[i,]
      X1=XM
      pf1 <- pf(X1, c1, c2, c3)
      nbd=c(pf1) 
      #stores profit values of the most profitable neighborhood onto which we move
      #first element is the profit at the current allocation
      for(t in 1:1000)
      {
        mat1 <- multcomp:::contrMat(1:length(X1), "Tukey")	
        mat2 <- -1*mat1	
        nbd1 <- c(apply(mat1, 1, function(i)
        {X1 + i}))
        nbd2 <- c(apply(mat2, 1, function(i)
        {X1 + i}))
        Prof=NULL 
        for(g in 1:ncol(nbd1))
        {
          pf2 <- pf(nbd1[,g], c1, c2, c3)
          pf3 <- pf(nbd2[,g], c1, c2, c3)
          if (pf2>pf3)
          {Prof=c(Prof, pf2)} 
          else if (pf2<pf3)
          {Prof=c(Prof, pf3)}
        }
        m = seq(1,length(Prof))
        m=i[Prof==min(Prof)]
        if(min(Prof)>max(nbd))
        {
          nbd=c(nbd, min(Prof))
          if(pf(nbd1[,m], c1, c2, c3)>=pf(nbd2[,m], c1, c2, c3)) 
          {X1=nbd1[,m]}
          else if(pf(nbd1[,m], c1, c2, c3)<pf(nbd2[,m], c1, c2, c3))
          {X1=nbd2[,m]}
        }
        else if(min(Prof)<max(nbd))
        {Profit=c(Profit, max(nbd))
         break}
      }
    }
  }
  print(mean(Profit))
}
