pf <-
function(X1, c1, c2, c3) 
  #generates a profit value for a given allocation and set of coefficients; 
  #this is needed for the next functions
{
  N=length(X1)
  X3=NULL
  for(k in 1:(N-1))
  {
    for(l in (k+1):N)
    {if(k!=1)
    {X3=c(X3, X1[k]*X1[l])}
    }
  }
  profit=sum(c1*X1)+sum(c2*(X1^2))+sum(c3*X3)
  print(profit)
}
