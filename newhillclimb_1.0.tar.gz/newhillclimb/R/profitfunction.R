profitfunction <-
function(Budget, N) 
  #function takes a budget and a number of inputs from the user
  #gives mean profits of all allocations for a 1000 different landscapes   
{
  library(EMT)
  X=findVectors(N, Budget) 
  #creates every possible allocation that meets the budget constraint
  Profits=NULL 
  #stores the mean profits from each set of coefficients
  for (j in 1:100)  
    #loop for creating a 100 different set of coefficients
  {
    c1=c(runif(N, -1,1))   #randomly generated set of coefficients between -1 & 1
    c2=c(runif(N, -1,1))   #set of coefficients for the squares
    c3=c(runif(choose(N-1,2), -1, 1)) 
    #coefficients of the crossproducts
    #the number of elements of the cross prod is always choose(N-1,2)
    P.alloc=NULL 
    #stores profit from each set of allocations 
    #for the jth set of coefficients
    for (i in 1: nrow(X))
    {
      X1=X[i, ]
      X2=(X1^2)
      X3=NULL
      for (k in 1:(N-1)) 
      { 
        for (l in (k+1):N) 
        { 
          if(k!=l) { X3=c(X3, X1[k]*X1[l]) } 
        } #generates the crossproduct 
      } 
      P.alloc=c(P.alloc, sum(c1* X1)+sum(c2*X2)+sum(c3*X3)) 
      #profits from every possible allocation
    }
    Profits <- c(Profits, (mean(P.alloc))) 
    #vector with mean profits from each set of coefficients
  }
  print(Profits)
}
