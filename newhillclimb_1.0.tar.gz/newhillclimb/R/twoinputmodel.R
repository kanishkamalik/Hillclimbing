twoinputmodel <-
function(B) 
  #takes a budget and creates a 3D landscape for 2 inputs
  #uses 1000 different set of random coefficients between -1 & 1
{
  library(scatterplot3d)
  X3=NULL
  X4=NULL
  P2=NULL
  for (j in 1:1000) #1000 sets will be generated
  {
    c1=c(runif(5, -1, 1)) #vector of five randomly generated coefficients. 
    X1=NULL
    X2=NULL
    P=NULL
    for(i in 1:B)
    {
      X1=c(X1, i) #vector with all possible allocations of input 1
      X2=c(X2, B-i) # vector with all possible allocations of input 2
      X=c(i, B-i, (i^2), ((B-i)^2), (i*(B-i)))
      P=c(P, sum(c1*X)) #profit function
    }
    X3=c(X3, X1) #all the values of the input, X1, get stored in one vector
    X4=c(X4, X2) #all the values of the input, X2, get stored in one vector
    P2=c(P2, P) #all the profit values get stored in one vector. 
    #This allows us to print all the landscapes at once
  }
  scatterplot3d(X3, X4, P2) #3D graph
}
