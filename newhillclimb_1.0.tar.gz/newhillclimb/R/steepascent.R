steepascent <-
function(Budget, N)
  #function that makes climbs to the most profitable neighborhood
  #only one connection between the input variables
{
  library(EMT)
  library(multcomp)
  X=findVectors(N, Budget) 
  Profit=NULL 
  #vector containing local maxima of each set of coefficients
  for (j in 1:1000)
  {
    c1=c(runif(N, -1,1))
    c2=c(runif(N, -1,1))
    c3=c(runif(choose(N-1,2), -1,1))
    for(i in 1:nrow(X))
    {
      XM=X[i,]
      X1=XM
      pf1 <- pf(X1, c1, c2, c3)
      nbd=c(pf1) 
      #stores profit values of the most profitable neighborhood
      #we move; first element is the profit at the current allocation
      for(t in 1:1000)
      {
        mat1 <- multcomp:::contrMat(1:length(X1), "Tukey")	
        #creates a special type of matrix, 
        #when added to the the current allocation, generates every neighborhood
        #1 is added to the first term and subtracted from the second term 
        mat2 <- -1*mat1	#inverts mat1 as 
        #1 is instead subtracted from the first term and added to the second term
        nbd1 <- c(apply(mat1, 1, function(i)
        {X1 + i}))
        nbd2 <- c(apply(mat2, 1, function(i)
        {X1 + i}))
        Prof=NULL 
        #vector with profit values of all neighborhoods of an allocation
        #from this we will select the most profitable point
        for(g in 1:ncol(nbd1)) #iterates through every neighborhood
        {
          pf2 <- pf(nbd1[,g], c1, c2, c3)
          pf3 <- pf(nbd2[,g], c1, c2, c3)
          if (pf2>pf3)
          {Prof=c(Prof, pf2)} 
          else if (pf2<pf3)
          {Prof=c(Prof, pf3)}
        }
        m = seq(1,length(Prof))
        m=i[Prof==max(Prof)] 
        #stores position of the most profitable column vector in the neighborhoods matrix
        if(max(Prof)>max(nbd)) 
          #checks if the neighborhood is more profitable than our current position
        {
          nbd=c(nbd, max(Prof))
          if(pf(nbd1[,m], c1, c2, c3)>=pf(nbd2[,m], c1, c2, c3)) 
          {X1=nbd1[,m]} 
          #this allows us to move from our current position the most profitable neighborhood
          else if(pf(nbd1[,m], c1, c2, c3)<pf(nbd2[,m], c1, c2, c3))
          {X1=nbd2[,m]}
        }
        else if(max(Prof)<max(nbd)) 
          #if the neighborhood is < current position, this is the local maxima
        {Profit=c(Profit, max(nbd))
         break}
      }
    }
  }
  print(mean(Profit)) #prints mean value of the local maxima 
}
